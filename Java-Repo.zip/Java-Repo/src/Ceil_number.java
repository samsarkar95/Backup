import java.util.Scanner;

public class Ceil_number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner u=new Scanner(System.in);
       System.out.println("Enter a Number");
       float d=u.nextFloat();
       float deci=d;
       int s= Math.round(d);
       double l=deci-s;
       if(l>0)
       {
    	   System.out.println(s+1);
       }
       else {
		l=s;
		System.out.println(l);
	}
	}

}
