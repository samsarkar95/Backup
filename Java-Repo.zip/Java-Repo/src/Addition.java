import java.util.Scanner;
public class Addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner a=new Scanner(System.in);
		 System.out.println("Enter Two Numbers");
		 int x=a.nextInt();
		 int y=a.nextInt();
		 int z=x+y;
		 System.out.println("The Addtion Result is : "+z);
	}

}
