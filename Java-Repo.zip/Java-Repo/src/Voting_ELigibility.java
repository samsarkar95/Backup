import java.util.Scanner;

public class Voting_ELigibility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner p=new Scanner (System.in);
        System.out.println("Enter Age of Citizen !!");
        int o=p.nextInt();
        if(o<18)
        {
        	System.out.println("Not Eligible to Vote !!!");
        }
        else
        {
        	System.out.println("Eligible to Vote !!!");
        }
	}

}
