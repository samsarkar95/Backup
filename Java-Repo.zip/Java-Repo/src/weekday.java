import java.util.Scanner;

public class weekday {

	private static Scanner in;

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in); 
		System.out.println("Enter the day : ");
		String d = in.next();
		System.out.println(d);
		String day = "NA";
		if (d =="Saturday") 
		{
			day = "Weekend";
		}
//		else 
//		{
//			day ="Weekday";
//		}
		System.out.println(day);
	}

}