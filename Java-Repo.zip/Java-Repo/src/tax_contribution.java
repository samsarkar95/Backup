import java.util.Scanner;

public class tax_contribution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner u=new Scanner(System.in);
   System.out.println("Enter Basic Salary,Tax Deduction & House Allowance !!");
   int b=u.nextInt();
   int t=u.nextInt();
   int h=u.nextInt();
   int g=h+t+b;
   if(g>55000)
   {
	   double N = (g-(g * 0.082)); 
	   System.out.println("Gross Salary is : "+g+" & Net Salary is : "+N );
   }
   else
   {
	   double N = (g-(g * 0.04));
	   System.out.println("Gross Salary is : "+g+" & Net Salary is : "+N );
   }
   
	}
}
