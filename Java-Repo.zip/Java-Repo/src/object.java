import java.util.Scanner;

class Calculator {
    // Method definition - here, numberOne and numberTwo are formal parameters or arguments
	int calculateSum(int numberOne, int numberTwo) {
		return numberOne+numberTwo;
	}
}
public class object {
	public static void main(String[] args) {
		Calculator calculator=new Calculator();
		Scanner i=new Scanner(System.in);
		System.out.println("Enter Two Number : ");
		int numberOne=i.nextInt();
		int numberTwo=i.nextInt();
		
        //Method call - here, numberOne and numberTwo are actual parameters or arguments
		int sum=calculator.calculateSum(numberOne, numberTwo);
		System.out.println("The sum is "+sum);
	}
}
