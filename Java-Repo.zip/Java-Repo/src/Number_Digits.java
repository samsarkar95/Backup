import java.util.Scanner;

public class Number_Digits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n,c=0;
     Scanner s=new Scanner(System.in);
     System.out.println("Enter a Number");
      n=s.nextInt();
     while(n>0)
     {
    	 n=n/10;
    	 c=c+1;
     }
     System.out.println("The number of Digits are : "+c);
	}

}
