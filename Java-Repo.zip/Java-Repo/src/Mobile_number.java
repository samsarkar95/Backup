import java.util.Scanner;

public class Mobile_number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner i=new Scanner(System.in);
     System.out.println("Enter Mobile Number");
     long b=i.nextLong();
     long a=b;
     int c=0;
     
     while(b!=0)
     {
    	 b=b/10;
    	 c=c+1;
     }
     if(c==10)
       {
      	 System.out.println(a+" is a Valid Number !!!");
       }
       else
       {
      	 System.out.println(a+ " is not a Valid Number !!!");
       }
	}
}
