import java.util.Scanner;

public class Complex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner r=new Scanner(System.in);
     System.out.println("Enter First complex Number :");
     double r1=r.nextDouble();
     double i1=r.nextDouble();
     System.out.println("Enter Second complex Number :");
     double i2=r.nextDouble();
     double r2=r.nextDouble();
     
     double r3=r1+r2;
     double i3=i1+i2;
     System.out.println("The Output is : "+r3+"+i "+i3);
	}

}
