import java.util.Scanner;

public class coin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x,y,z;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the amount of coins");
		x=s.nextInt(); // 4
		y=s.nextInt();// 12
		z=s.nextInt(); // 21
		int fiveNeeded = (z/5); // 21/5 = 4--$5
		int fiveAvailable = x; // 4--$5
		int fiveNeed = 0;
		int e;
		if(fiveNeeded >= fiveAvailable) {
			fiveNeed = fiveAvailable;
		}
		int oneNeeded = z-(fiveNeeded * 5); // 21 - 20 
		if(oneNeeded <= y) {
			e = oneNeeded + fiveNeeded;
			System.out.println("Number of 1$ coins are "+ oneNeeded);
			System.out.println("Number of 5$ coins are "+ fiveNeeded);
		}
		else {
			System.out.println("NP");
		}
		
		
		}	
		}
