import java.util.Scanner;

public class Net_salary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner (System.in);
    System.out.println("Enter basic Salary,Tranport Allowance & House Allowance : ");
    int b=s.nextInt();
    int t=s.nextInt();
    int h=s.nextInt();
    int g=b+t+h;
    if(g>55000)
    {
    	double N =  (g-( 0.082 * g));
    	System.out.println(" The net Salary is : "+N);
    }
	}

}
