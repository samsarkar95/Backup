import React, { Component } from 'react'

export class UserGreet extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         isLoggedIn: false
      }
    }
  render() {
    // let Message
    // if(this.state.isLoggedIn)
    // {
    //     Message=<div>Hello Bishal</div>
    // }
    // else
    //     {
    //         Message=<div>Hello Guest</div>
    //     }
    //     return <div>{Message}</div>

    // if(this.state.isLoggedIn)
    // {
    //     return ( <div>
    //          Hello Bishal 
    //          </div>
    //     )
    // }
    // else
    // {
    //     return (
    //         <div> Hello Guest</div>
    //     )
        
    // }
    // return (
    //   <div>
    //     <div>Hello Guest</div>
    //     Hello Bishal
    //     </div>
    // )
    // return
    //  this.state.isLoggedIn ? 
    //  (<div>Hello Bishal</div>) :
    //  (<div>Hello Guest</div>)   
    
    return this.state.isLoggedIn && <div>Welcome Bishal</div>
   }
}
  


export default UserGreet