import React, { Component } from 'react'

 class FormComponent extends Component {
constructor(props) {
  super(props)

  this.state = {
    comments: '',
    username: '',
    topic: ''
  }
}
handleusenamechange=(event)=>{
    this.setState({
         username:event.target.value,
})
}

handlecommentchange=(event)=>{
  this.setState({
       comments:event.target.value
  }) 
}
handletopicchange=(event)=>{
  this.setState({
       topic:event.target.value
  }) 
}
handelsubmit=(event)=>{
  alert(`${username} ${topic} ${comments}`)
  event.preventDefault()
}

  render() {
    const {username,comments,topic}=  this.state
       return (
    <form onSubmit={this.handelsubmit}>
      <div>
           <label>Username</label>
           <input type='text'
           value={username}
           onChange={this.handleusenamechange} ></input>
      </div>
      <div>
        <label>Comments</label>
        <textarea value={comments}
          onChange={this.handlecommentchange}></textarea>
      </div>
      <div>
        <select value={topic}
        onChange={this.handletopicchange}>
          <option value='react'>React</option>
          <option value='angular'>Angular</option>
          <option value='java'>Java</option>
        </select>
      </div>
      <div>
        <button type='submit'>Submit</button>
      </div>
    </form>  
    )
  }
}
export default FormComponent
