import React, { Component } from 'react'
import ChildComp from './ChildComp';

 class ParentComp extends Component {
  
    constructor(props) 
    {
      super(props)

      this.state= ({
        parentname: 'Dad'
      })
      this.greetparent=this.greetparent.bind(this);//Binding Class method to a property
    }
  
    greetparent(childName)
    {
      alert(`Hello ${this.state.parentname} from ${childName}`)
    }
   
    render() {
    return (
    <div>
     <ChildComp greethandler={this.greetparent}></ChildComp> {/*Calling Child property by passing parent method as prop*/}
    </div>
    )
   }
}

export default ParentComp