import React, { Component } from 'react'

function clicker()
{
  console.log("Button clicked");
}
function functionclick() {
  return (
    <div>
        <button onClick={clicker}>Click</button>

    </div>
  )
}

export default functionclick
