import React, { Component } from 'react'

class Eventbind extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         message: 'Hello'
      }
      this.clickhandler=this.clickhandler.bind(this)
    }
    clickhandler=()=>{
        this.setState({
            message: "Good Bye !!!"
        })
    }
    // clickhandler()
    // {
    //     this.setState({
    //         message: "Good Bye !!!"
    //     })
    //     console.log(this);
    // }
  render() {
    return (
      <div>
          <div>{this.state.message}</div>
   
         <button onClick={this.clickhandler.bind(this)}>Click</button> {/*Using Render Method */}
         <button onClick={()=>this.clickhandler()}>Click</button> {/* using Bind keyword */}
         <button onClick={this.clickhandler}>Click</button>  {/*Using Constructor */}
         <button onClick={this.clickhandler}>Click</button> {/* Using Class Property*/ }
      </div>
    )
  }
}

export default Eventbind