import React, { Component } from 'react'
import LifeCyleB from './LifeCycleB';

 class LifeCyleA extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name: "Samrat"
      }
      console.log("Constructor Method A");
    }
     static getDerivedStateFromProps(state,props)
    {
        console.log('getDerivedStateFromProps A');
        return null
    }
  
    componentDidMount() {
        console.log(" component A Mount");
    }
    shouldComponentUpdate()
    {
        console.log("A shouldComponentUpdate");
        return true
    }
    componentDidUpdate()
    {
        console.log("A componentDidUpdate");
    
    }
    getSnapshotBeforeUpdate(prevState,prevProps)
    {
        console.log("A getSnapshotBeforeUpdate");
        return null
    }
    changestate=()=>
    {
        this.setState
        ({
           name: "Naiiccee"
         })
    }
  render() {
    console.log("Render JSX A");
    return (
      <div>LifeCyle A
        <div><button onClick={this.changestate}>Change State</button></div>
      <LifeCyleB/>
      </div>
    )
  }
}

export default LifeCyleA