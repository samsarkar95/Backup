import React from 'react'
import './Mystyle.css'
function Stylesheet1(props) {
  let className=props.p ? 'Primary' : ''
  return (
    <h1 className={`${className} font-xl`}>Stylesheet</h1>
  )
}

export default Stylesheet1