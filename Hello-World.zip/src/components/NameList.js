import React from 'react'
import Person from './Person'
function NameList() {
  // const Names=['Bishal','Ashif','Aniket']
  // const NameList= Names.map(name=><h1>{name}</h1>)
  //  const P=[
  //          {id :1,Name :"Bishal",
  //           age : 27,Skill: "Angular",},
  //          {id :2,Name :"Aniket",
  //           age : 28,Skill: "React"},
  //          {id :3,Name :"Sayantan",
  //           age : 29,Skill: "javaScript"}
  //         ]
          const N=['Bishal','Samrat','Bishal']
          const Nl=N.map(( M,index)=><h2 key={index}> {index} {M}</h2>)
          // const PL =P.map(Per=>
          //   (<Person key={Per.Name} Per={Per}></Person>)
          //   )
          
  return (
    <div>
       {/* <h2>{Names[0]}</h2>
       <h2>{Names[1]}</h2>
       <h2>{Names[2]}</h2> */}
       {/* {
        Names.map(name=><h1>{name}</h1>)
       } */}
       
       {/* {PL} */}
       {Nl}
    </div>
  )
}

export default NameList