import React from 'react'

function Person({Per}) {
  return (
    <div> 
          <h2>I am {Per.Name},
             I am {Per.age} Years Old &
             I Know {Per.Skill} 
          </h2>
        </div>
  )
}

export default Person