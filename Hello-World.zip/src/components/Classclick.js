import React, { Component } from 'react'

export class Classclick extends Component {
    clicker2()
    {
        console.log("Button has Clicked !!!");
    }
  render() {
    return (
      <div>
        <button onClick={this.clicker2}>Click Me</button>
      </div>
    )
  }
}

export default Classclick