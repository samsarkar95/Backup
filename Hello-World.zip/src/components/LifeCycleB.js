import React, { Component } from 'react'

 class LifeCyleB extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name: "Samrat"
      }
      console.log("Constructor B Method");
    }
     static getDerivedStateFromProps(state,props)
    {
        console.log('getDerivedStateFromProps B');
        return null
    }
    componentDidMount() {
        console.log(" component B Mount");
    }
    shouldComponentUpdate()
    {
        console.log("B shouldComponentUpdate");
        return true
    }
    componentDidUpdate()
    {
        console.log("B componentDidUpdate");
    
    }
    getSnapshotBeforeUpdate()
    {
        console.log("B getSnapshotBeforeUpdate");
        return null
    }
  render() {
    console.log("Render JSX B");
    return (
      <div>LifeCyle B</div>
    )
  }
}

export default LifeCyleB