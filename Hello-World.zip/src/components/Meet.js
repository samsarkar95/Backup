import React from 'react';

// function Greet()
// {
//     return <h1>Hello Sam</h1>
// }
// const Meet=()=>
//     <h1>Hello Sam !!!</h1>

   //  const Meet =(props)=>{
   //      console.log(props);
   //      return(  <div >
   //         <h1>{props.name} a.k.a {props.heroname}</h1>
   //         {props.children}
   //         </div> )
            const Meet =(props)=>{     
             const {name,heroname}=props //Extracting variables from props
               return( 
                   <div >
                  <h1>{name} a.k.a {heroname}</h1>
                  </div> )
      //   return React.createElement(
      //      'div',
      //      {id:'hell', className: "Bosh"},
      //      React.createElement('h1',null,'naiiccee'));
     }

export default Meet;