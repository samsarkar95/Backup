import React from 'react'

const Heading={
    fontSize:'60px',
    color: 'blue'
}
function Inline() {
  return (
    <h2 style={Heading}>Inline</h2>
  )
}

export default Inline