import React from 'react'

function ChildComp(props) {
  return (
    <div>
        <button onClick={()=>{props.greethandler('Son')}}>Greet Parent </button>
    </div>
  )
}

export default ChildComp