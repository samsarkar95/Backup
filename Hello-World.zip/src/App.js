import './App.css';
import React from 'react';
 import Meet from './components/Meet';
 import Welcome from './components/Welcome';
 import Message from './components/Message';
 import Counter from './components/Counter';
 import Functionclick from './components/Functionclick';
 import Classclick from './components/Classclick';
 import Eventbind from './components/Eventbind'
import ParentComp from './components/ParentComp';
import UserGreet from './components/UserGreet';
import NameList from './components/NameList';
import Stylesheet1 from './components/Stylesheet1';
import Inline from './components/Inline';
import './Styles.css'
import styles from './AppStyles.module.css'
import FormComponent from './components/FormComponent'
import LifeCyleA from './components/LifeCyleA';
function App() {
  return (
    <div className="App">
      {/* <h1 className='error'>Success!!!!</h1>
      <h1 className={styles.success}>Error !!!</h1> */}
      {/* <FormComponent/> */}
      <LifeCyleA></LifeCyleA>
      {/* <UserGreet/> */}
      {/* <NameList/> */}
      {/* <Stylesheet1 p={true}/> */}
      {/* <Inline/> */}
      {/* <ParentComp></ParentComp> */}
      {/* <Eventbind/> */}
      {/* <Functionclick></Functionclick>
      <Classclick></Classclick> */}
      {/* <Meet name="Samrat" heroname='Batman'></Meet> */}
      {/* <Welcome name='Bishal' heroname='superman'></Welcome> */}
      {/* <Welcome
      name='Samrat' heroname='Spiderman'> <p>Sum of all the elements</p></Welcome>
      <button>Action</button> 
      { <Message></Message> }
       <Counter></Counter> */}
    </div>
  );
}

export default App;
